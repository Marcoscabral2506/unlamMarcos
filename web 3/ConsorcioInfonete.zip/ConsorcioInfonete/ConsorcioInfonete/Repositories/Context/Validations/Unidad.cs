﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repositories.Context
{
    [MetadataType(typeof(UnidadMetadata))]
    public partial class Unidad
    {
    }
}
