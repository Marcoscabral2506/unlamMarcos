# InfoneteRecargado
Trabajo Práctico Final - Programación Web 3 - UNLAM

Integrantes:
Cabral Marcos - Aguino Ailen - Rodriguez Federico - Garcia Tomas

En obtenerExpensas.SQL se encuentra el store procedure que utilizamos para la API de expensas.