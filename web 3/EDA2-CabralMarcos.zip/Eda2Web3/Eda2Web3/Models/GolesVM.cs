﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Eda2Web3.Models
{
    public class GolesVM
    {
        [Required(ErrorMessage = "Cantidad de goles requerida")]
        [Range(1, 1000, ErrorMessage = "La cantidad de goles debe ser entre 1 y 1000")]
        public int CantidadGoles { get; set; }

        [Required(ErrorMessage = "El equipo es requerido")]
        public string equipo { get; set; }

        [Required(ErrorMessage = "El jugador es requerido")]
        [Range(1, Double.PositiveInfinity,ErrorMessage ="Seleccione un jugador")]
        public int idJugador{get;set;}
        
    }
}