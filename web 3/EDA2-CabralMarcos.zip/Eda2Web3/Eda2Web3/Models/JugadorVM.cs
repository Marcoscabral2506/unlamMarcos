﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Eda2Web3.Models
{
    public class JugadorVM
    {
        [Required(ErrorMessage = "El nombre del jugador es requerido")]
        [StringLength(80, ErrorMessage = "El texto tiene que tener entre 1 y 80 caracteres", MinimumLength = 1)]
        public string Nombre { get; set; }
    }
}