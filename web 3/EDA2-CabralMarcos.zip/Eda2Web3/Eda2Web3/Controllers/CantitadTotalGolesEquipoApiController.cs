﻿using Repositorios;
using Servicios;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Eda2Web3.Controllers
{
    public class CantitadTotalGolesEquipoApiController : ApiController
    {

        private GolesPorJugadorEquipoServicio golesServicio;
        // GET: api/CantitadTotalGolesEquipoApi/5
        public string Get(string equipo)
        {
            golesServicio= new GolesPorJugadorEquipoServicio(new Eda2Web3Entities());
            return golesServicio.CantidadGolesPorEquipo(equipo);
        }

    }
}
