﻿using Eda2Web3.Models;
using Repositorios;
using Servicios;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Eda2Web3.Controllers
{
    public class GolesController : Controller
    {
        private GolesPorJugadorEquipoServicio golesServicio;
        private JugadoresServicio jugadoresServicio;

        public GolesController()
        {
            Eda2Web3Entities contexto = new Eda2Web3Entities();
            golesServicio = new GolesPorJugadorEquipoServicio(contexto);
            jugadoresServicio = new JugadoresServicio(contexto);

        }
       
        public ActionResult ListaGolesJugador()
        {
            List<GolesPorJugadorEquipo> goles = golesServicio.ObtenerTodos();
            return View(goles);
        }
        public ActionResult AltaGoles()
        {
            return View(new GolesVM());
        }
        [HttpPost]
        public ActionResult AltaGoles(GolesVM goles)
        {
            //le faltaron campos
            if (!ModelState.IsValid)
            {
                return View();
            }

            GolesPorJugadorEquipo gol = new GolesPorJugadorEquipo()
            {
                equipo = goles.equipo,
                cantidadGoles = goles.CantidadGoles,
                idJugador = goles.idJugador
            };
            golesServicio.Alta(gol);
            return RedirectToAction("/ListaGolesJugador");
        }
    }
}