﻿using Repositorios;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Servicios
{
    public class GolesPorJugadorEquipoServicio
    {
        private Eda2Web3Entities ctx;
        private GolesPorJugadorEquipoRepositorio repo;
        public GolesPorJugadorEquipoServicio(Eda2Web3Entities contexto)
        {
            ctx = contexto;
            repo = new GolesPorJugadorEquipoRepositorio(contexto);
        }

        public void Alta(GolesPorJugadorEquipo g)
        {
            ValidarRegistro(g);
        }
        public void ValidarRegistro(GolesPorJugadorEquipo g)
        {
            var query = (from x in ctx.GolesPorJugadorEquipo
                         where x.idJugador == g.idJugador
                        && x.equipo == g.equipo
                         select x).FirstOrDefault();
            //cargo por primera vez
            if (query == null)
            {
                repo.Agregar(g);
            }
            else
            {
                repo.ActualizarGolesDeJugador(g);
            }

        }
        public List<GolesPorJugadorEquipo> ObtenerTodos()
        {
            return repo.ObtenerTodos();
        }

        public string CantidadGolesPorEquipo(string equipo)
        {
            return repo.CantidadTotalGolesEquipo(equipo);
        }
    }

}
