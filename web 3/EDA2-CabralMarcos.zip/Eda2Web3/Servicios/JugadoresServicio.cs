﻿using Repositorios;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Servicios
{
    public class JugadoresServicio
    {
        protected Eda2Web3Entities ctx;
        private JugadoresRepositorio repo;
        public JugadoresServicio(Eda2Web3Entities contexto) 
        {
            ctx = contexto;
            repo = new JugadoresRepositorio(contexto);
        }

        public Boolean Alta(Jugador jugador)
        {
           return repo.Agregar(jugador);
        }

        public List<Jugador> ObtenerTodos()
        {
            return repo.ObtenerTodos();
        }
    }
}
