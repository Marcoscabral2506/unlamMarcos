﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repositorios
{
    public class JugadoresRepositorio
    {
        Eda2Web3Entities ctx;
        public JugadoresRepositorio(Eda2Web3Entities contexto)
        {
            ctx = contexto;
        }
        public List<Jugador> ObtenerTodos()
        {
            var query = from j in ctx.Jugador
                        select j;
            return query.ToList();
        }
        public Boolean Agregar(Jugador j)
        {
            if (ValidarJugador(j.nombre)==true)
            {
                ctx.Jugador.Add(j);
                ctx.SaveChanges();
                return true;
            }
            return false;
        }
        //si devuelve true es porque no hay jugadores con ese nombre
        //valida que el jugador no haya sido ingresado
        public Boolean ValidarJugador(string nombre)
        {
            Boolean flag = false;

            var query = (from j in ctx.Jugador
                        where j.nombre == nombre
                        select j).FirstOrDefault();
            if(query == null)
            {
                flag = true;
            }
            
            return flag;
        }
    }
}
