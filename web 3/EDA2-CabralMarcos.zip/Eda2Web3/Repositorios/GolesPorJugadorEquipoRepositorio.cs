﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repositorios
{
    public class GolesPorJugadorEquipoRepositorio
    {
        Eda2Web3Entities ctx;
        public GolesPorJugadorEquipoRepositorio(Eda2Web3Entities contexto)
        {
            ctx = contexto;
        }

        public void Agregar(GolesPorJugadorEquipo g)
        {
            ctx.GolesPorJugadorEquipo.Add(g);
            ctx.SaveChanges();
        }
        public List<GolesPorJugadorEquipo> ObtenerTodos()
        {
            var query = from g in ctx.GolesPorJugadorEquipo
                        select g;

            return query.ToList();
        }

        public void ActualizarGolesDeJugador(GolesPorJugadorEquipo g)
        {
            var update = (from j in ctx.GolesPorJugadorEquipo
                          where j.idJugador == g.idJugador
                          select j).FirstOrDefault();
            update.cantidadGoles = g.cantidadGoles;
            ctx.SaveChanges();
        }

        public string CantidadTotalGolesEquipo(string equipo)
        {
            var query = (from g in ctx.GolesPorJugadorEquipo
                        where g.equipo.Contains(equipo)
                        select new { g.cantidadGoles }).ToList();

            var sum = query.Select(c=>c.cantidadGoles).Sum();

            return sum.ToString();
        }

    }
}
