create database Eda2Web3;

create table Jugador(
	id int identity primary key,
	nombre varchar(50)
);


create table GolesPorJugadorEquipo(
	id int identity primary key ,
	cantidadGoles int,
	equipo varchar(50),
	idJugador int,
	foreign key (idJugador) references Jugador(id)
);
insert into Jugador values('Martin Palermo');
insert into Jugador values('Lionel Messi');
insert into Jugador values('Juan Roman Riquelme');

select * from Jugador;