{{> headerLogeado}}
<h5>Gracias por comprar en InfoNete! vuelva al inicio para ver su compra</h5>
<a href="/" class="btn btn-outline-danger my-3 ml-3">Volver</a>
{{> footer}}